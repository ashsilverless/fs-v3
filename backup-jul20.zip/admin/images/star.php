<svg version="1.1" class="star" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="452.9px" height="430.7px" viewBox="0 0 452.9 430.7" style="enable-background:new 0 0 452.9 430.7;" xml:space="preserve">
<polygon points="226.4,0 279.9,164.5 452.9,164.5 312.9,266.2 366.4,430.7 226.4,329 86.5,430.7 139.9,266.2 0,164.5 173,164.5 "/>
</svg>
