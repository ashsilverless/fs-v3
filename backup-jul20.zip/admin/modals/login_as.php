<!--Modal: Log In As-->
<div class="modal fade log-in-as" id="modalCLIENT" tabindex="-1" role="dialog" aria-labelledby="modalCLIENT" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <!--Content-->
    <div class="modal-content">
      <!--Body-->
      <div class="modal-body">
        <div class="embed-responsive">
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          <iframe class="embed-responsive-item" src="" allowfullscreen></iframe>
        </div>
      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<!--Modal: Name-->
