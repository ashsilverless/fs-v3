<!-- Delete Modal-->
  <div class="modal fade " id="chart" tabindex="-1" role="dialog" aria-labelledby="chart" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content" style="background-color:#444;">
        <div class="modal-header" style="border:none;">
          <!--<h5 class="modal-title" id="charttitle" style="color:white">Valuation Chart</h5>-->
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" style="color:white;font-weight:bold;">×</span>
          </button>
        </div>
        <div class="modal-body">
			<div class="chart-data row h-100 justify-content-center align-items-center" style="min-height:565px;"><p style="color:white;"><i class="fas fa-spinner"></i> Compiling Chart Data</p></div> 
		</div>
      </div>
    </div>
  </div>
