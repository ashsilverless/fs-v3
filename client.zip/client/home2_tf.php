<?php
include 'inc/db.php';     # $host  -  $user  -  $pass  -  $db
/*
ini_set ("display_errors", "1");	error_reporting(E_ALL);
    */

$user_id = $_SESSION['fs_client_featherstone_uid'];
$client_code = $_SESSION['fs_client_featherstone_cc'];


$client_code = '1111';


$last_date = getLastDate('tbl_fs_transactions','fs_transaction_date','fs_transaction_date','fs_client_code = "'.$client_code.'"');

$lastlogin = date('g:ia \o\n D jS M y',strtotime(getLastDate('tbl_fsusers','last_logged_in','last_logged_in','id = "'.$_SESSION['fs_client_user_id'].'"')));
$testVar = 'test';
try {
  // Connect and create the PDO object
  $conn = new PDO("mysql:host=$host; dbname=$db", $user, $pass);
  $conn->exec("SET CHARACTER SET $charset");      // Sets encoding UTF-8


     //    Get the general products data for Client   ///


  $query = "SELECT * FROM tbl_fsusers where fs_client_code LIKE '$client_code' AND bl_live = 1;";
	

  $result = $conn->prepare($query);
  $result->execute();

  // Parse returned data
  while($row = $result->fetch(PDO::FETCH_ASSOC)) {
	  $user_name = $row['user_name'];
	  $linked_accounts = $row['linked_accounts'];
  }


     //    Get the products   ///

  $query = "SELECT DISTINCT fs_product_type FROM `tbl_fs_transactions` where fs_client_code LIKE '$client_code' AND bl_live = 1;";

  $result = $conn->prepare($query);
  $result->execute();

  // Parse returned data
  while($row = $result->fetch(PDO::FETCH_ASSOC)) {
      $products[] = $row;
  }

  $conn = null;        // Disconnect

}

catch(PDOException $e) {
  echo $e->getMessage();
}

?>

<?php
define('__ROOT__', dirname(dirname(__FILE__)));
require_once(__ROOT__.'/header.php');
require_once(__ROOT__.'/page-sections/header-elements.php');
require_once(__ROOT__.'/page-sections/sidebar-elements.php');
?>

    <div class="col-md-9">
        <div class="border-box main-content daily-data">
            <div class="main-content__head">
                <h1 class="heading heading__1">Daily Valuation Data</h1>
                <p>Data accurate as at <?= date('j M y',strtotime($last_date));?></p>
                <div class="button button__raised data-toggle"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 19.59 19.59"><defs><style>.cls-1{fill:#1d1d1b;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="cls-1" d="M0,9.79A9.84,9.84,0,0,1,9.79,0a9.85,9.85,0,0,1,9.8,9.79,9.85,9.85,0,0,1-9.8,9.8A9.85,9.85,0,0,1,0,9.79Zm15.48,6.38L9.61,10.41a.7.7,0,0,1-.22-.56V1.28a8.53,8.53,0,1,0,6.09,14.89ZM17.1,5.38a8.53,8.53,0,0,0-6.67-4.09v7.9Zm-.89,10.05A8.54,8.54,0,0,0,17.58,6.3l-6.7,3.84Z"/></g></g></svg> View Charts</div>

            </div>
            <h2 class="heading heading__2"><?=$user_name;?></h2>
			
			
			<?php
			
			$total_inv_ammount = 0;
			foreach ($products as $product):
				
				$funds = db_query("SELECT DISTINCT fs_isin_code FROM `tbl_fs_transactions` where fs_client_code LIKE '$client_code' AND fs_product_type LIKE '".$product['fs_product_type']."';");
			
				foreach ($funds as $fund):

					$records = db_query("SELECT * FROM `tbl_fs_transactions` where fs_client_code LIKE '$client_code' AND fs_deal_type NOT LIKE 'Periodic Advisor Charge' AND fs_product_type LIKE '".$product['fs_product_type']."' AND fs_isin_code LIKE '".$fund['fs_isin_code']."';");
			
					$total_shares = 0;

			
					for($count=0;$count<count($records);$count++){
						$total_shares += $records[$count]['fs_shares'];
						$total_inv_ammount += round($records[$count]['fs_shares'] * $records[$count]['fs_t_price'],2);
					}

					
					$tot_inv_ammount[$product['fs_product_type']] += $total_inv_ammount;
			
					$value_of_shares[$product['fs_product_type']] += round((get_current_price($fund['fs_isin_code']) * $total_shares),2);
			
					$total_product_shares[$product['fs_product_type']] += $total_shares;
			
				endforeach;
			
			
			
			endforeach;
			
			################################
			
			echo ('<b>Total Shares Held / Product Type</b><br>');
			
			foreach ($total_product_shares as $tot_share => $shares_qty):
			
				$gain = number_format($value_of_shares[$tot_share] - $tot_inv_ammount[$tot_share],2);
				$gain_percent = number_format(100*($value_of_shares[$tot_share]/$tot_inv_ammount[$tot_share])-100,4);
			
				$total_quantity_of_shares_per_product += $shares_qty;
			
				$ac_name = getField('tbl_fsusers','user_name','fs_client_code',$client_code);
			
				echo ($ac_name.'-'.$tot_share.' : '.$shares_qty.' shares : Total Investment Amount : '.$tot_inv_ammount[$tot_share].' : Value of shares : '.$value_of_shares[$tot_share].' : Gain : '.$gain.' : Gain % : '.$gain_percent.'<br>');
			
			endforeach;
			
			
			################################

			foreach ($products as $product):
			
				echo('<br><b>'.$product['fs_product_type'].'</b><br>');

				$funds = db_query("SELECT DISTINCT fs_isin_code FROM `tbl_fs_transactions` where fs_client_code LIKE '$client_code' AND fs_product_type LIKE '".$product['fs_product_type']."';");
			
			
				foreach ($funds as $fund):
			
					echo('ISIN Code : '.$fund['fs_isin_code'].'<br><table border="0" cellspacing="4" cellpadding="4">');
	





		
					echo ('<tr><td>Holding</td><td>Invested</td><td>Book Cost</td><td>Value</td><td>Growth(£)</td><td>Growth(%)</td><td>Benchmark</td></tr>');
			
					$records = db_query("SELECT * FROM `tbl_fs_transactions` where fs_client_code LIKE '$client_code' AND fs_deal_type NOT LIKE 'Periodic Advisor Charge' AND fs_product_type LIKE '".$product['fs_product_type']."' AND fs_isin_code LIKE '".$fund['fs_isin_code']."';");
			
					$value = $cps = $totshares = $count = 0;    $average_cps = $total_shares = array();
			
					for($count=0;$count<count($records);$count++){
						$totshares += $records[$count]['fs_shares'];
						$total_shares[$count] = $total_shares[$count-1] + $records[$count]['fs_shares'];
						$value = round($records[$count]['fs_shares'] * $records[$count]['fs_t_price'],2);

						
						//              ((E2*B2)+D3)/B3           (0 x 0) + 444  /  222  =  2
						//										  (2 x 222) + 40 /  232  =  2.09
						//										  (2.09 x 232) + 50 / 242 = 2.21
						//                      (previous acps * previous total shares)  +  share calc   /  current total shares  
						
						if($records[$count]['fs_shares'] > 0){
							$average_cps[$count] = round((($average_cps[$count-1] * $total_shares[$count-1])+$value)/$totshares,2);
						}else{
							$average_cps[$count] = $average_cps[$count-1];
						}
						
						$book_cost = round($average_cps[$count] * $total_shares[$count],2);
						
						$invested_in_fund += $records[$count]['fs_iam'];
						
						$growth = $value - $invested_in_fund;
						
                        $growth_percent = ($growth/$invested_in_fund) * 100;
						
						// echo ('<tr><td>'.$records[$count]['fs_transaction_date'].'</td>');	    //  Transaction Date    
						// echo ('<td>'.$records[$count]['fs_shares'].'</td>');    				//  Purchase / Sale				A
						// echo ('<td>'.$total_shares[$count].'</td>');							//  Shares Held					B
						// echo ('<td>'.$records[$count]['fs_t_price'].'</td>');					//  Cost / Share				C
						// echo ('</td><td>&pound;'.$inv_ammount.'</td>');							//  Share Calc					D
						// echo ('<td>'.$average_cps[$count].'</td>');								//  Av. Cost / Share			E
						// echo ('<td>&pound;'.$book_cost.'</td></tr>');									//  Book Cost					F
	
					}
			
					echo ('<tr><td>'.$totshares.'</td>');	    //  Transaction Date    
					echo ('<td>'.$invested_in_fund.'</td>');    				//  Purchase / Sale				A
					echo ('<td>'.$book_cost.'</td>');							//  Shares Held					B
					echo ('<td>'.$value.'</td>');					//  Cost / Share				C
					echo ('</td><td>&pound;'.$growth.'</td>');							//  Share Calc					D
					echo ('<td>'.$growth_percent.'</td>');								//  Av. Cost / Share			E
					echo ('<td>&pound;'.$book_cost.'</td></tr>');									//  Book Cost					F


			
			
					$last_good_price = get_current_price($fund['fs_isin_code']);
			
					echo ('<tr><td colspan="7"><b>Total Shares held  :  '.$totshares.'</td></tr>');
					$percentage_of_shares = round(($totshares / $total_quantity_of_shares_per_product)*100,2);
					echo ('<tr><td colspan="7"><b>Total Shares held  :  '.$totshares.' at '.$last_good_price.' = &pound;'.($totshares*$last_good_price).' which is '.$percentage_of_shares.'% of total within product type.<br>Invested Amount : '.$invested_in_fund.'</b></td></tr>');
			
					echo ('</table><p>&nbsp;</p>');

			
				endforeach;
			
			
			
			endforeach;
			?>

        

			<?php if ($linked_accounts != ''){ ?>
					<h3>LINKED ACCOUNTS</h3>
				<?php 
			$lnkarray = explode('|',$linked_accounts);
						$lnk_array = array_filter($lnkarray);

					foreach ($lnk_array as $lnk_client_code): 
						
						try {
						  // Connect and create the PDO object
						  $conn = new PDO("mysql:host=$host; dbname=$db", $user, $pass);
						  $conn->exec("SET CHARACTER SET $charset");      // Sets encoding UTF-8

					     //    Get the products   ///

						  $query = "SELECT DISTINCT fs_product_type FROM `tbl_fs_transactions` where fs_client_code LIKE '$lnk_client_code' AND bl_live = 1;";

						  $la_products = array();

						  $result = $conn->prepare($query);
						  $result->execute();

						  // Parse returned data
						  while($row = $result->fetch(PDO::FETCH_ASSOC)) {
							  $la_products[] = $row;
						  }
						$conn = null;        // Disconnect
						}
						catch(PDOException $e) {
						  echo $e->getMessage();
						}
						
			
			$total_inv_ammount = 0;
			foreach ($la_products as $product):
				
				$funds = db_query("SELECT DISTINCT fs_isin_code FROM `tbl_fs_transactions` where fs_client_code LIKE '$lnk_client_code' AND fs_product_type LIKE '".$product['fs_product_type']."';");
			
				foreach ($funds as $fund):

					$records = db_query("SELECT * FROM `tbl_fs_transactions` where fs_client_code LIKE '$lnk_client_code' AND fs_deal_type NOT LIKE 'Periodic Advisor Charge' AND fs_product_type LIKE '".$product['fs_product_type']."' AND fs_isin_code LIKE '".$fund['fs_isin_code']."';");
			
					$total_shares = 0;

			
					for($count=0;$count<count($records);$count++){
						$total_shares += $records[$count]['fs_shares'];
						$total_inv_ammount += round($records[$count]['fs_shares'] * $records[$count]['fs_t_price'],2);
					}

					
					$tot_inv_ammount[$product['fs_product_type']] += $total_inv_ammount;
			
					$value_of_shares[$product['fs_product_type']] += round((get_current_price($fund['fs_isin_code']) * $total_shares),2);
			
					$total_product_shares[$product['fs_product_type']] += $total_shares;
			
				endforeach;
			
			
			
			endforeach;
			
			################################
			
			echo ('<b>Total Shares Held / Product Type</b><br>');
			
			foreach ($total_product_shares as $tot_share => $shares_qty):
			
				$gain = number_format($value_of_shares[$tot_share] - $tot_inv_ammount[$tot_share],2);
				$gain_percent = number_format(100*($value_of_shares[$tot_share]/$tot_inv_ammount[$tot_share])-100,4);
			
				$total_quantity_of_shares_per_product += $shares_qty;
	
				$lnk_name = getField('tbl_fsusers','user_name','fs_client_code',$lnk_client_code);
			
				echo ($lnk_name.'-'.$tot_share.' : '.$shares_qty.' shares : Total Investment Amount : '.$tot_inv_ammount[$tot_share].' : Value of shares : '.$value_of_shares[$tot_share].' : Gain : '.$gain.' : Gain % : '.$gain_percent.'<br>');
			
			endforeach;
			
			
			################################

			foreach ($la_products as $product):
			
				echo('<br><b>'.$product['fs_product_type'].'</b><br>');
	
				

				$funds = db_query("SELECT DISTINCT fs_isin_code FROM `tbl_fs_transactions` where fs_client_code LIKE '$lnk_client_code' AND fs_product_type LIKE '".$product['fs_product_type']."';");
			
			
				foreach ($funds as $fund):
			
					echo('ISIN Code : '.$fund['fs_isin_code'].'<br><table border="0" cellspacing="4" cellpadding="4">');
	





		
					echo ('<tr><td>Holding</td><td>Invested</td><td>Book Cost</td><td>Value</td><td>Growth(£)</td><td>Growth(%)</td><td>Benchmark</td></tr>');
			
					$records = db_query("SELECT * FROM `tbl_fs_transactions` where fs_client_code LIKE '$lnk_client_code' AND fs_deal_type NOT LIKE 'Periodic Advisor Charge' AND fs_product_type LIKE '".$product['fs_product_type']."' AND fs_isin_code LIKE '".$fund['fs_isin_code']."';");
			
					$value = $cps = $totshares = $count = 0;    $average_cps = $total_shares = array();
			
					for($count=0;$count<count($records);$count++){
						$totshares += $records[$count]['fs_shares'];
						$total_shares[$count] = $total_shares[$count-1] + $records[$count]['fs_shares'];
						$value = round($records[$count]['fs_shares'] * $records[$count]['fs_t_price'],2);

						
						//              ((E2*B2)+D3)/B3           (0 x 0) + 444  /  222  =  2
						//										  (2 x 222) + 40 /  232  =  2.09
						//										  (2.09 x 232) + 50 / 242 = 2.21
						//                      (previous acps * previous total shares)  +  share calc   /  current total shares  
						
						if($records[$count]['fs_shares'] > 0){
							$average_cps[$count] = round((($average_cps[$count-1] * $total_shares[$count-1])+$value)/$totshares,2);
						}else{
							$average_cps[$count] = $average_cps[$count-1];
						}
						
						$book_cost = round($average_cps[$count] * $total_shares[$count],2);
						
						$invested_in_fund += $records[$count]['fs_iam'];
						
						$growth = $value - $invested_in_fund;
						
                        $growth_percent = ($growth/$invested_in_fund) * 100;
						
						// echo ('<tr><td>'.$records[$count]['fs_transaction_date'].'</td>');	    //  Transaction Date    
						// echo ('<td>'.$records[$count]['fs_shares'].'</td>');    				//  Purchase / Sale				A
						// echo ('<td>'.$total_shares[$count].'</td>');							//  Shares Held					B
						// echo ('<td>'.$records[$count]['fs_t_price'].'</td>');					//  Cost / Share				C
						// echo ('</td><td>&pound;'.$inv_ammount.'</td>');							//  Share Calc					D
						// echo ('<td>'.$average_cps[$count].'</td>');								//  Av. Cost / Share			E
						// echo ('<td>&pound;'.$book_cost.'</td></tr>');									//  Book Cost					F
	
					}
			
					echo ('<tr><td>'.$totshares.'</td>');	    //  Transaction Date    
					echo ('<td>'.$invested_in_fund.'</td>');    				//  Purchase / Sale				A
					echo ('<td>'.$book_cost.'</td>');							//  Shares Held					B
					echo ('<td>'.$value.'</td>');					//  Cost / Share				C
					echo ('</td><td>&pound;'.$growth.'</td>');							//  Share Calc					D
					echo ('<td>'.$growth_percent.'</td>');								//  Av. Cost / Share			E
					echo ('<td>&pound;'.$book_cost.'</td></tr>');									//  Book Cost					F


			
			
					$last_good_price = get_current_price($fund['fs_isin_code']);
			
					echo ('<tr><td colspan="7"><b>Total Shares held  :  '.$totshares.'</td></tr>');
					$percentage_of_shares = round(($totshares / $total_quantity_of_shares_per_product)*100,2);
					echo ('<tr><td colspan="7"><b>Total Shares held  :  '.$totshares.' at '.$last_good_price.' = &pound;'.($totshares*$last_good_price).' which is '.$percentage_of_shares.'% of total within product type.<br>Invested Amount : '.$invested_in_fund.'</b></td></tr>');
			
					echo ('</table><p>&nbsp;</p>');

			
				endforeach;
			
			
			
			endforeach;
			?>
			
			

			<?php endforeach; // End For

				}  //  End If ?>


<div class="data-section chart">
    <div class="container">

        <div class="row">
            <div class="col-md-12">
                <canvas class="my-4 w-100 chartjs-render-monitor" id="linechart" height="400"></canvas>

            </div>
        </div>

    </div>
</div>



</div>

</div>

</div>

</div>
<?php
require_once('../page-sections/footer-elements.php');
define('__ROOT__', dirname(dirname(__FILE__)));
require_once(__ROOT__.'/modals/logout.php');
require_once(__ROOT__.'/modals/time-out.php');
require_once(__ROOT__.'/global-scripts.php');?>

   <script>

		Chart.defaults.global.legend.display = false;

/* ##########################################       LINE CHART     ################################################## */

		<?php
		try {
		  // Connect and create the PDO object
		  $conn = new PDO("mysql:host=$host; dbname=$db", $user, $pass);
		  $conn->exec("SET CHARACTER SET $charset");      // Sets encoding UTF-8

			// Latest Date
			$monthago = Date("Y-m-d", strtotime("2020-01-23 -60 days"));

		//    Get the price data for Client Graph   ///

		  $query = "SELECT * FROM `tbl_fs_transactions` where fs_deal_type NOT LIKE 'Periodic Advisor Charge' AND fs_product_type LIKE 'ISA' AND fs_client_code LIKE '$client_code' AND bl_live = 1 AND fs_transaction_date > '$monthago' ORDER BY fs_transaction_date ASC;";

		  $result = $conn->prepare($query);
		  $result->execute();

		  // Parse returned data
		  while($row = $result->fetch(PDO::FETCH_ASSOC)) {
			  $data1 .= $row['fs_t_price']*$row['fs_shares'].',';
			  $labels1 .= "'".$row['fs_transaction_date']."',";
		  }

		}

		catch(PDOException $e) {
		  echo $e->getMessage();
		}
		?>

		var ctxline = document.getElementById('linechart');
		var myLineChart = new Chart(ctxline, {
			type: 'line',
			data: {
				datasets: [{
					fill:false,
					lineTension:.3,
					borderColor:['rgba(0, 0, 0, 1)'],
					borderWidth:1,
                    color: ['rgba(253, 0, 0, 0.95)'],
					label:'Performance Data',
					data:[<?=$data1;?>],
				}],
				labels: [<?=$labels1;?>]
			},

			options: { tooltips: {enabled: true}}
		});
    </script>
  </body>
</html>
